﻿using StudnetResultsMgt;
using System;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using Xunit;

namespace StudnetResultsMgt
{
    public class AdminModelTests
    {
        [Fact(DisplayName = "Create Admin Model @create-item-model")]
        public void AdminModelTest()
        {
            var filePath = ".." + Path.DirectorySeparatorChar + ".." + Path.DirectorySeparatorChar + ".." + Path.DirectorySeparatorChar + ".." + Path.DirectorySeparatorChar + "SRM_API" + Path.DirectorySeparatorChar + "Models" + Path.DirectorySeparatorChar + "Admin.cs";
            Assert.True(File.Exists(filePath), "`Admin.cs` was not found in the `Models` folder.");

            var AdminModel = TestHelpers.GetUserType("SRM_API.Models.Admin");

            Assert.True(AdminModel != null, "`Admin` class was not found, ensure `Admin.cs` contains a `public` class `Admin`.");
            var AdminId = AdminModel.GetProperty("AdminId");
            Assert.True(AdminId != null && AdminId.PropertyType == typeof(int), "`Admin` class did not contain a `public` `int` property `AdminId`.");
            var AdminFirstName = AdminModel.GetProperty("AdminFirstName");
            Assert.True(AdminFirstName != null && AdminFirstName.PropertyType == typeof(string), "`Admin` class did not contain a `public` `string` property `AdminFirstName`.");
            Assert.True(AdminFirstName.GetCustomAttributes(typeof(RequiredAttribute), false).FirstOrDefault() != null, "`Admin` class's `FirstName` property didn't have a `Required` attribute. (the `RequiredAttribute` can be found in the `System.ComponentModel.DataAnnotations` namespace)");
            Assert.True(((MaxLengthAttribute)AdminFirstName.GetCustomAttributes(typeof(MaxLengthAttribute), false)?.FirstOrDefault())?.Length == 100, "`Admin` class's `FirstName` property didn't have a `MaxLength` attribute of `100`.");
            var AdminLastName = AdminModel.GetProperty("AdminLastName");
            Assert.True(AdminLastName != null && AdminLastName.PropertyType == typeof(string), "`Admin` class did not contain a `public` `string` property `AdminLastName`.");
            Assert.True(AdminLastName.GetCustomAttributes(typeof(RequiredAttribute), false).FirstOrDefault() != null, "`Admin` class's `AdminLastName` property didn't have a `Required` attribute. (the `RequiredAttribute` can be found in the `System.ComponentModel.DataAnnotations` namespace)");
            Assert.True(((MaxLengthAttribute)AdminFirstName.GetCustomAttributes(typeof(MaxLengthAttribute), false)?.FirstOrDefault())?.Length == 100, "`Admin` class's `AdminLastName` property didn't have a `MaxLength` attribute of `100`.");
            var AdminEmail = AdminModel.GetProperty("AdminEmail");
            Assert.True(AdminEmail != null && AdminEmail.PropertyType == typeof(string), "`Admin` class did not contain a `public` `string` property `AdminEmail`.");
            Assert.True(AdminEmail.GetCustomAttributes(typeof(RequiredAttribute), false).FirstOrDefault() != null, "`Admin` class's `AdminEmail` property didn't have a `Required` attribute. (the `RequiredAttribute` can be found in the `System.ComponentModel.DataAnnotations` namespace)");
            Assert.True(((MaxLengthAttribute)AdminEmail.GetCustomAttributes(typeof(MaxLengthAttribute), false)?.FirstOrDefault())?.Length == 100, "`Admin` class's `AdminLastName` property didn't have a `MaxLength` attribute of `100`.");
            var AdminGender = AdminModel.GetProperty("AdminGender");
            Assert.True(AdminGender != null && AdminGender.PropertyType == typeof(string), "`Admin` class did not contain a `public` `string` property `AdminGender`.");
            Assert.True(AdminGender.GetCustomAttributes(typeof(RequiredAttribute), false).FirstOrDefault() != null, "`Admin` class's `AdminGender` property didn't have a `Required` attribute. (the `RequiredAttribute` can be found in the `System.ComponentModel.DataAnnotations` namespace)");
            Assert.True(((MaxLengthAttribute)AdminGender.GetCustomAttributes(typeof(MaxLengthAttribute), false)?.FirstOrDefault())?.Length == 7, "`Admin` class's `AdminGender` property didn't have a `MaxLength` attribute of `7`.");
            var AdminCity = AdminModel.GetProperty("AdminCity");
            Assert.True(AdminCity != null && AdminCity.PropertyType == typeof(string), "`Admin` class did not contain a `public` `string` property `AdminCity`.");
            Assert.True(AdminCity.GetCustomAttributes(typeof(RequiredAttribute), false).FirstOrDefault() != null, "`Admin` class's `AdminCity` property didn't have a `Required` attribute. (the `RequiredAttribute` can be found in the `System.ComponentModel.DataAnnotations` namespace)");
            Assert.True(((MaxLengthAttribute)AdminCity.GetCustomAttributes(typeof(MaxLengthAttribute), false)?.FirstOrDefault())?.Length == 50, "`Admin` class's `AdminCity` property didn't have a `MaxLength` attribute of `50`.");
            var AdminPassword = AdminModel.GetProperty("AdminPassword");
            Assert.True(AdminPassword != null && AdminPassword.PropertyType == typeof(string), "`Admin` class did not contain a `public` `string` property `AdminCity`.");
            Assert.True(AdminPassword.GetCustomAttributes(typeof(RequiredAttribute), false).FirstOrDefault() != null, "`Admin` class's `AdminPassword` property didn't have a `Required` attribute. (the `RequiredAttribute` can be found in the `System.ComponentModel.DataAnnotations` namespace)");
            Assert.True(((MaxLengthAttribute)AdminPassword.GetCustomAttributes(typeof(MaxLengthAttribute), false)?.FirstOrDefault())?.Length == 225, "`Admin` class's `AdminPassword` property didn't have a `MaxLength` attribute of `225`.");
            var ConfirmPassword = AdminModel.GetProperty("ConfirmPassword");
            Assert.True(ConfirmPassword != null && ConfirmPassword.PropertyType == typeof(string), "`Admin` class did not contain a `public` `string` property `ConfirmPassword`.");
            Assert.True(ConfirmPassword.GetCustomAttributes(typeof(RequiredAttribute), false).FirstOrDefault() != null, "`Admin` class's `ConfirmPassword` property didn't have a `Required` attribute. (the `RequiredAttribute` can be found in the `System.ComponentModel.DataAnnotations` namespace)");
            Assert.True(((MaxLengthAttribute)ConfirmPassword.GetCustomAttributes(typeof(MaxLengthAttribute), false)?.FirstOrDefault())?.Length == 225, "`Admin` class's `ConfirmPassword` property didn't have a `MaxLength` attribute of `225`.");
            





        }

        [Fact(DisplayName = "Add Item to ApplicationDbContext @add-item-to-applicationdbcontext")]
        public void MyContextTest()
        {
            // Get appropriate path to file for the current operating system
            var filePath = ".." + Path.DirectorySeparatorChar + ".." + Path.DirectorySeparatorChar + ".." + Path.DirectorySeparatorChar + ".." + Path.DirectorySeparatorChar + "SRM_API" + Path.DirectorySeparatorChar + "Context" + Path.DirectorySeparatorChar + "MyContext.cs";
            // Assert Admin.cshtml is in the Views/Home folder
            Assert.True(File.Exists(filePath), "`MyContext.cs` was not found in the `Data` folder.");

            var applicationDbContext = TestHelpers.GetUserType("SRM_API.Context.MyContext");

            Assert.True(applicationDbContext != null, "`MyDbContext` class was not found, ensure `MyContext.cs` contains a `public` class 'MyContext`.");

            var itemsProperty = applicationDbContext.GetProperty("Admin");
            Assert.True(itemsProperty != null, "`MyContext` class did not contain a `public` `Admin` property.");
            Assert.True(itemsProperty.PropertyType.GenericTypeArguments[0].ToString() == "SRM_API.Models.Admin", "`MyContext` class's `Admin` property was not of type `DbSet<Admin>`.");
        }
    }
}
