﻿using System;
using System.IO;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace StudnetResultsMgt
{
    public class MyContextTests
    {
        [Fact(DisplayName = "Create Class MyContext @create-class-applicationdbcontext")]
        public void MyContextTest()
        {
            // Get appropriate path to file for the current operating system
            var filePath = ".." + Path.DirectorySeparatorChar + ".." + Path.DirectorySeparatorChar + ".." + Path.DirectorySeparatorChar + ".." + Path.DirectorySeparatorChar + "SRM_API" + Path.DirectorySeparatorChar + "Context" + Path.DirectorySeparatorChar + "MyContext.cs";
            // Assert Index.cshtml is in the Views/Home folder
            Assert.True(File.Exists(filePath), "`MyContext.cs` was not found in the `Data` folder.");

            var myContext = TestHelpers.GetUserType("SRM_API.Context.MyContext");

            Assert.True(myContext != null, "`MyContext` class was not found, ensure `MyContext.cs` contains a `public` class `MyContext`.");
            Assert.True(myContext.BaseType == typeof(DbContext), "`MyContext` was found, but did not inherit the `MyContext` class. (this will require a using directive for the `Microsoft.EntityFrameWorkCore` namespace)");
        }

        [Fact(DisplayName = "Add Constructor to MyContext @add-constructor-to-applicationdbcontext")]
        public void AddConstructorToMyContextTest()
        {
            // Get appropriate path to file for the current operating system
            var filePath = ".." + Path.DirectorySeparatorChar + ".." + Path.DirectorySeparatorChar + ".." + Path.DirectorySeparatorChar + ".." + Path.DirectorySeparatorChar + "SRM_API" + Path.DirectorySeparatorChar + "MyContext" + Path.DirectorySeparatorChar + "MyContext.cs";
            // Assert Index.cshtml is in the Views/Home folder
            Assert.True(File.Exists(filePath), "`MyContext.cs` was not found in the `Data` folder.");

            var myContext = TestHelpers.GetUserType("SRM_MVC.Context.MyContext");

            Assert.True(myContext != null, "`MyContext` class was not found, ensure `MyContext.cs` contains a `public` class `MyContext`.");
            Assert.True(myContext.BaseType == typeof(DbContext), "`MyContext` was found, but did not inherit the `DbContext` class. (this will require a using directive for the `Microsoft.EntityFrameWorkCore` namespace)");

            var constructor = myContext.GetConstructor(new Type[] { typeof(DbContextOptions) });
            Assert.True(constructor != null, "`MyContext` does not appear to contain a constructor accepting a parameter of type `DbContextOptions<MyContext>`");
        }
    }
}
